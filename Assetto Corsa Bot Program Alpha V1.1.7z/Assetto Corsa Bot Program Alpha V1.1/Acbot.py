# =============================================================================
# >> IMPORTS
# =============================================================================
# Python Imports
import time
import os
import socket
import struct
import traceback
import hashlib
import threading
import math
import random
import winsound
import binascii
import msvcrt
import queue
import ctypes
import sys
import pickle

# =============================================================================
# >> GLOBAL VARIABLES
# =============================================================================


IP = 'Address Here'
PORT = 9922
PASSWORD ='q'
CARNAME = 'ks_mazda_miata'
COUNTRY = 'SWE'

# Path to assetto corsa dedicated server
PATH_ROOT = os.path.dirname(__file__)
PATH_REPLAY = os.path.join(PATH_ROOT, 'replay')
PATH_POSITION = os.path.join(PATH_ROOT, 'position')
PATH_ASETTOCORSA = 'D:\\steam\\steamapps\\common\\assettocorsa'

# AC Protocol version
AC_PROTOCOL_VERSION = 202

# >> TCP Packet IDs
ACP_DRIVER_SYNC = 13        # Packet Id for syncing player list
ACP_DRIVER_SYNC2 = 14       # Similar as above with just 1 byte
ACP_UPDATE_DAMAGE = 21
ACP_INVALID_PASSWORD = 60
ACP_REQ_CONNECTION = 61
ACP_SERVER_INFO = 62
ACP_REQ_DRIVER_LIST = 63
ACP_ANS_DRIVER_LIST = 64
ACP_INVALID_PROTOCOL = 66
ACP_REQ_DISCONNECT = 67
ACP_CHECKSUM = 68
ACP_SERVER_FULL = 69
ACP_CHAT_MESSAGE = 71
ACP_LAP_COMPLETE = 73       # Packet  that returns to the bot program to reset bot position after completed run
ACP_EVENT_DISCONNECT = 77   # Packet that tells  the server bot is disconnecting
ACP_REQ_TYRE_CHANGE = 80
ACP_DRIVER_NAME_LIST = 91   # List of drivers, Uses entry list name if available? or just entry? i.e ACP_ENTRY_LIST?
ACP_DRIVER_KICK = 104
ACP_UNKNOWN_112 = 112       # Data count + [car_id + 8bytes]..
ACP_UNKNOWN_120 = 120       # Contains current weather name, and probably other weather data?


# >> UDP Packet IDs
ACP_UPDATE_CAR = 70
ACP_INIT_UDP = 78
ACP_CLIENT_ALIVE = 79       # After the second ping reponse, client sends this with byte "\x01" .
ACP_CLIENT_PING = 248
ACP_SERVER_PING = 249

P_SIZE_FMT = 'H' # Packet Size FMT
P_ID_FMT = 'B' # Packet ID FMT
P_SIZE_FMT_LEN = struct.calcsize(P_SIZE_FMT)
P_ID_FMT_LEN = struct.calcsize(P_ID_FMT)

# For debugging..
PACKET_ID_TRANSLATION = {

    # TCP
    ACP_UPDATE_DAMAGE: 'ACP_UPDATE_DAMAGE',
    ACP_REQ_CONNECTION: 'ACP_REQ_CONNECTION',
    ACP_SERVER_INFO: 'ACP_SERVER_INFO',
    ACP_REQ_DRIVER_LIST: 'ACP_REQ_DRIVER_LIST',
    ACP_ANS_DRIVER_LIST: 'ACP_ANS_DRIVER_LIST',
    ACP_CHECKSUM: 'ACP_CHECKSUM',
    ACP_REQ_TYRE_CHANGE: 'ACP_REQ_TYRE_CHANGE',
    ACP_REQ_DISCONNECT: 'ACP_REQ_DISCONNECT',
    ACP_INVALID_PASSWORD: 'ACP_INVALID_PASSWORD',
    ACP_CHAT_MESSAGE: 'ACP_CHAT_MESSAGE',
    ACP_SERVER_FULL: 'ACP_SERVER_FULL (or car slots/invalid car name)',
    ACP_DRIVER_NAME_LIST: 'ACP_DRIVER_NAME_LIST',
    ACP_UNKNOWN_120: 'ACP_UNKNOWN_120',
    ACP_DRIVER_SYNC: 'ACP_DRIVER_SYNC?',
    ACP_DRIVER_SYNC2: 'ACP_DRIVER_SYNC2?',
    ACP_UNKNOWN_112: 'ACP_UNKNOWN_112',
    ACP_LAP_COMPLETE: 'ACP_LAP_COMPLETE?',
    ACP_DRIVER_KICK: 'ACP_DRIVER_KICK',
    ACP_INVALID_PROTOCOL: 'ACP_INVALID_PROTOCOL',

    # UDP
    ACP_UPDATE_CAR: 'ACP_UPDATE_CAR',
    ACP_INIT_UDP: 'ACP_INIT_UDP',
    ACP_SERVER_PING: 'ACP_SERVER_PING',
    ACP_CLIENT_PING: 'ACP_CLIENT_PING',
    ACP_CLIENT_ALIVE: 'ACP_CLIENT_ALIVE',
}

# Available contries
COUNTRIES = [
    'ABW', 'AC', 'AFG', 'AGO', 'AIA', 'ALB', 'AND', 'ARE', 'ARG', 'ARM', 'ASM',
    'ATA', 'ATG', 'AUS', 'AUT', 'AZE', 'BDI', 'BEL', 'BEN', 'BFA', 'BGD', 'BGR',
    'BHR', 'BHS', 'BIH', 'BLR', 'BLZ', 'BMU', 'BOL', 'BRA', 'BRB', 'BRN', 'BTN',
    'BWA', 'CAF', 'CAN', 'CCK', 'CHE', 'CHL', 'CHN', 'CIV', 'CMR', 'COD', 'COG',
    'COK', 'COL', 'COM', 'CPV', 'CRI', 'CUB', 'CYM', 'CYP', 'CZE', 'DEU', 'DJI',
    'DMA', 'DNK', 'DOM', 'DZA', 'ECU', 'EGY', 'ENG', 'ERI', 'ESH', 'ESP', 'EST',
    'ETH', 'FIN', 'FJI', 'FRA', 'FRO', 'FSM', 'GAB', 'GBR', 'GEO', 'GGY', 'GHA',
    'GIB', 'GIN', 'GMB', 'GNB', 'GNQ', 'GRC', 'GRD', 'GRL', 'GTM', 'GUM', 'GUY',
    'HKG', 'HND', 'HRV', 'HTI', 'HUN', 'IDN', 'IMN', 'IND', 'IRL', 'IRN', 'IRQ',
    'ISL', 'ISR', 'ITA', 'JAM', 'JEY', 'JOR', 'JPN', 'KAZ', 'KEN', 'KGZ', 'KHM',
    'KIR', 'KNA', 'KOR', 'KWT', 'LAO', 'LBN', 'LBR', 'LCA', 'LIE', 'LKA', 'LSO',
    'LTU', 'LUX', 'LVA', 'MAC', 'MAR', 'MCO', 'MDA', 'MDG', 'MDV', 'MEX', 'MHL',
    'MKD', 'MLI', 'MLT', 'MMR', 'MNE', 'MNG', 'MOZ', 'MRT', 'MSR', 'MTQ', 'MUS',
    'MWI', 'MYS', 'NAM', 'NCL', 'NER', 'NGA', 'NIC', 'NIR', 'NLD', 'NOR', 'NPL',
    'NRU', 'NZL', 'OMN', 'PAK', 'PAN', 'PER', 'PHL', 'PLW', 'PNG', 'POL', 'PRI',
    'PRT', 'PRY', 'PYF', 'QAT', 'ROU', 'RUS', 'RWA', 'SAU', 'SCT', 'SDN', 'SEN',
    'SGP', 'SLB', 'SLE', 'SLV', 'SMR', 'SOM', 'SRB', 'STP', 'SUR', 'SVK', 'SVN',
    'SWE', 'SWZ', 'SYC', 'SYR', 'TCA', 'TCD', 'TGO', 'THA', 'TJK', 'TKM', 'TLS',
    'TON', 'TTO', 'TUN', 'TUR', 'TUV', 'TWN', 'TZA', 'UGA', 'UKR', 'URY', 'USA',
    'UZB', 'VCT', 'VEN', 'VGB', 'VIR', 'VNM', 'VUT', 'WLS', 'WSM', 'YEM', 'ZAF',
    'ZMB', 'ZWE'
]

COUNTRIES_EU = [
    'AUT', 'BEL', 'BGR', 'HRV', 'CYP', 'CZE', 'DNK', 'EST', 'SVN', 'ESP', 'SVK',
    'FIN', 'FRA', 'DEU', 'GRC', 'HUN', 'IRL', 'ITA', 'LVA', 'SWE', 'GBR', 'ROU',
    'LTU', 'LUX', 'MLT', 'NLD', 'POL', 'PRT',
]

BOT_NAMES = [  #pretty self explanitory these are the names the program uses for bots.  You can change these if you want custom names.
    'Traffic1', 'Traffic2', 'Traffic3', 'Traffic4', 'Traffic5', 'Traffic6',
    'Traffic7', 'Traffic8', 'Traffic9', 'Traffic10', 'Traffic11',
    'Traffic12', 'Traffic13', 'Traffic14', 'Traffic15', 'Traffic16',
    'Traffic17', 'Traffic18', 'Traffic19', 'Traffic20', 'Traffic21',
    'Traffic22', 'Traffic23', 'Traffic24', 'Traffic25', 'Traffic26', 'Traffic27', 'Traffic28',
    'Traffic29', 'Traffic30', 'Traffic31', 'Traffic32', 'Traffic33',
    'Traffic34', 'Traffic35',
]

BOT_STATE = [
    'Disconnected',
    'Connecting',
    'Connected',
    'Kicked',
]

KEY_ADD_BOT = b'1'
KEY_REMOVE_BOT = b'2'
KEY_SAVE_POSITION = b'3'
KEY_LOAD_POSITION = b'4'
KEY_TOGGLE_RECORD = b'5'
KEY_LOAD_REPLAY = b'6'
KEY_LOAD_POSITION_SETUP = b'7'
KEY_SAVE_POSITION_SETUP = b'8'
KEY_NEXT_BOT = b'+'
KEY_PREVIOUS_BOT = b'-'

# List of packets to log to file or = 'all' to log everything
#PACKETS_TO_LOG = [ACP_SERVER_INFO, ACP_DRIVER_NAME_LIST]
PACKETS_TO_LOG = 'all'
#PACKETS_TO_LOG = []

# Other
_print = print
messages = []
# p_srv_cfg = os.path.join(PATH_ACDS, 'cfg', 'server_cfg.ini')
# PATH_ROOT = os.path.dirname(__file__)
# packet_logs = os.path.join(PATH_ROOT, 'packet_logs')
# if not os.path.isdir(packet_logs):
#     os.mkdir(packet_logs)

# im not gonna lie I have no clue what he was going for with this one
# spawn_pos_drift = (
#     (58.312789699889116, 0.45999999999999996, 117.57959641282814, 170.3, 0.0, 0.0),
#     (61.24962137762003, 0.45999999999999996, 116.97620599307096, 168.5, 0.0, 0.0),
#     (64.22701051442223, 0.45999999999999996, 116.56866013543812, 170.3, 0.0, 0.0),
#     (66.93318466442057, 0.45999999999999996, 115.81987197345147, 168.5, 0.0, 0.0),
#     (70.05698663917282, 0.45999999999999996, 115.06487212350368, 170.3, 0.0, 0.0),
#     (72.81273289214536, 0.45999999999999996, 114.62366436694832, 168.5, 0.0, 0.0),
# )

X_AVG = 6.2853498458862305
Y_AVG = -3.7765350341796875
PB1 = (-60.620967864990234, 180.04571533203125, 0.4606695771217346, 59.015197674362994, 0.02434259743378038, -0.09973581631280797)
DRIFT_PITBOX_POSITION = {}
for i in range(18):
    DRIFT_PITBOX_POSITION[i] = (PB1[0] + (X_AVG * i), PB1[1] + (Y_AVG * i), PB1[2], PB1[3], PB1[4], PB1[5])

# =============================================================================
# >> EXCEPTIONS
# =============================================================================
class ParserError(Exception):

    def __init__(self, strerror, index=None, buf=None):
        self.strerror = strerror
        self.index = index
        self.buf = buf

    def __str__(self):
        return self.strerror

class ConnectionError(Exception):

    def __init__(self, strerror, errno=None):
        self.strerror = strerror
        self.errno = errno

class ProtocolError(Exception):

    def __init__(self, errno, strerror, *args):
        self.strerror = strerror.format(*args)
        self.errno = errno

    def __str__(self):
        return 'ProtocolError {}: {}'.format(self.errno, self.strerror)

# =============================================================================
# >> HELPERS
# =============================================================================
class StructParser:

    def __init__(self, fmt):
        self.fmt = fmt

    def put(self, values):
        try:
            try:
                values[0]
            except TypeError:
                values = [values]
            return struct.pack(self.fmt, *values)
        except struct.error as e:
            raise ParserError('Error trying to pack values {} with FMT {}'.format(values, self.fmt))

    def get(self, buf, index):
        try:
            result = struct.unpack_from(self.fmt, buf, index)
            if len(result) == 1:
                result = result[0]
            return result, index + struct.calcsize(self.fmt)
        except struct.error as e:
            raise ParserError('Unable to unpack FMT: {} at index: {}'.format(self.fmt, index), index, buf)

class StringParser:

    def __init__(self, fmt, encoding, errors='strict', esize=0):
        self.fmt = fmt
        self.encoding = encoding
        self.errors = errors
        self.esize = esize

    def put(self, string):
        try:
            buf = b''
            length = 0
            if not string is None:
                string = str(string)
                buf = string.encode(self.encoding, self.errors)[self.esize:]
                length = len(string)
            return struct.pack(self.fmt, length) + buf
        except struct.error as e:
            raise ParserError('Error trying to pack string length {} with FMT {}: {}'.format(length, self.fmt, e))
        except UnicodeEncodeError as e:
            raise ParserError('Error encoding string "{}" with encoding {}'.format(string, self.encoding))

    def get(self, buf, index):
        try:
            length, = struct.unpack_from(self.fmt, buf, index)
            start = index + struct.calcsize(self.fmt)
            stop = start + length * (self.esize if self.esize else 1)
            data = buf[start:stop].decode(self.encoding, self.errors)
            return data, stop
        except struct.error as e:
            raise ParserError('Unable to unpack FMT: {} at index: {}'.format(self.fmt, index), index, buf)
        except UnicodeDecodeError as e:
            raise ParserError('Decode error with encoding {}'.format(self.encoding), index, buf)

class ChecksumParser:

    def __init__(self, method):
        self.method = method

    def put(self, path):
        buf = b''
        with open(path, 'rb') as f:
            buf = self.method(f.read()).digest()
        return buf

    def get(self, buf, index):
        return None, index

class DummyParser:

    def put(self, data):
        return data

    def get(self, buf, index):
        return None, index

# =============================================================================
# >> BYTE DATA PARSERS
# =============================================================================
INT8 = StructParser('b')
UINT8 = StructParser('B')
INT16 = StructParser('h')
UINT16 = StructParser('H')
INT32 = StructParser('i')
UINT32 = StructParser('I')
FLOAT = StructParser('f')
ASCII = StringParser('B', encoding='ascii')
ASCII = StringParser('B', encoding='ascii')
UTF32 = StringParser('B', encoding='utf-32', esize=4)
UTF8 = StringParser('B', encoding='utf-8')
NOPARSER = DummyParser()
MD5 = ChecksumParser(hashlib.md5)

# =============================================================================
# >> BYTE DATA REPRESENTATION
# =============================================================================
class BytesData:

    def __init__(self, name=None, parser=None, skip_bytes=None, process=None, callback=None):
        self.name = name
        self.parser = parser
        self.skip_bytes = skip_bytes
        self.process = process
        self.callback = callback 

# =============================================================================
# >> PACKET HELPERS
# =============================================================================
class GenericPacket:
    packet_id = None
    _id_fmt = P_ID_FMT
    _content = ()

    def __init__(self, _obj=None, **kw):
        self._unknown = {}
        self._unknown_raw = b''
        self._dbg_lines = []
        self._obj = _obj or self
        if len(kw):
            if _obj is None:
                try:
                    for x in self._content:
                        if x.name is None:
                            continue
                        setattr(self, x.name, kw[x.name])
                except KeyError:
                    raise KeyError('Packet "%s" is missing a value for %s' % (type(self).__name__, x.name))
            else:
                for k,v in kw.items():
                    setattr(self._obj, k, v)

    def from_buffer(self, buf, index):
        try:
            # self.debug('Starting decoding packed ID {} ({})\n' + '*' * 112 + '\n', self.packet_id, PACKET_ID_TRANSLATION[self.packet_id])
            index = self.unpack(buf, index)
            # data = buf[index:]
            # bytes_left = len(data)
            # text = 'Decoding done! '
            # if bytes_left:
            #     self._unknown_raw += data
            #     text += 'Remaning bytes in buffer: {}:\n{}\n'
            # self.debug(text, bytes_left, data)
            return index
        except ParserError as e:
            r = str(e.buf[:e.index] + b' [ERROR]>>> ' + e.buf[e.index:])
            # self.debug('Parser error while unpacking buffer at index {}\n{}\n\n{}\n', e.index, e.strerror, r)
            raise Warning('[{}] Parser error while unpacking buffer at index {}\n{}\n'.format(self.__class__.__name__, e.index, e.strerror))
        # finally:
        #     if self.packet_id == ACP_UPDATE_CAR:
        #         return
        #     if PACKETS_TO_LOG == 'all' or self.packet_id in PACKETS_TO_LOG:
        #         # if self.packet_id == ACP_UPDATE_CAR:
        #         #     for l in self._dbg_lines:
        #         #         print(l[:-1])
        #         #     return

        #         # p = os.path.dirname(__file__)
        #         # p = os.path.join(p, 'packet_logs', PACKET_ID_TRANSLATION[self.packet_id])
        #         p = os.path.join(packet_logs, PACKET_ID_TRANSLATION[self.packet_id])
        #         c = 0
        #         while True:
        #             if os.path.isfile(p + '_{}.txt'.format(c)):
        #                 c += 1
        #                 continue
        #             break
        #         self.debug('\n')
        #         with open(p + '_{}.txt'.format(c), 'w') as f:
        #             f.writelines(self._dbg_lines)
        #             if self._unknown_raw:
        #                 f.write('\nUndecoded data:\n' + str(self._unknown_raw) + '\n\n')
        #             if self.packet_id == ACP_SERVER_INFO:
        #                 f.write('Server Config:\n')
        #                 with open(p_srv_cfg, 'r') as f2:
        #                     f.writelines(f2.readlines())

    def to_buffer(self):
        try:
            return struct.pack(self._id_fmt, self.packet_id) + self.pack()
        except ParserError as e:
            raise Warning('[{}] Parser error while packing data\n{}\n'.format(self.__class__.__name__, e.strerror))

    def unpack(self, buf, index):
        for x in self._content:
            #_start_index = index
            if x.skip_bytes is None:
                value, index = x.parser.get(buf, index)
                setattr(self, x.name, value)
                if x.callback:
                    index = getattr(self, x.callback)(value, index)
                # buf, index = self.unpack_callback(buf, index, x)
                # t0 = ('{}={}' if str(value).isdigit() else "{}='{}'").format(x.name, value)
                # t1 = '# INDEX({}-{}), FMT({}), FMT_SIZE({})\n'.format(_start_index, index, x.parser.fmt, struct.calcsize(x.parser.fmt))
                # self.debug('{:<86}{}', t0, t1)
            else:
                # data = buf[index:index+x.skip_bytes]
                # if x.name:
                #     self._unknown[name] = data
                # self._unknown_raw += data + b' '
                # self.debug('>> skipping {} bytes from index {}\n>> {}\n', x.skip_bytes, index, data)
                index += x.skip_bytes
        return index

    def pack(self):
        buf = b''
        for x in self._content:
            if x.skip_bytes is None:
                attr = getattr(self._obj, x.name)
                if not x.process is None:
                    attr = x.process(attr)
                if x.parser is None:
                    buf += attr
                else:
                    buf += x.parser.put(attr)
            else:
                buf += bytes(x.skip_bytes)
        return buf

    def debug(self, text, *args, **kw):
        self._dbg_lines.append(text.format(*args, **kw))

    def dict(self):
        return {x.name: getattr(self, x.name) for x in self._content if not x.name is None}

    def print_packet_info(self):
        # Trigger this on unknown/not registred packet and do all the
        # uncommented stuff above (in from_buffer)
        return

class VariablePacket(GenericPacket):
    packet_id = None
    _header = BytesData('count', UINT8)
    _content = ()

    def __init__(self, data=None):
        super().__init__()
        self.data = data or []

    def unpack(self, buf, index):
        count, index = self._header.parser.get(buf, index)
        #self.debug('Data count: {}\n', count)
        for i in range(count):
            r = []
            #self.debug('[{}]' + '-'*93 + '\n', i)
            #_start_index = index
            for x in self._content:
                if x.skip_bytes is None:
                    value, index = x.parser.get(buf, index)
                    r.append(value)
                    if x.callback:
                        index = getattr(self, x.callback)(value, index)
                    #t0 = ('{}={}' if str(value).isdigit() else "{}='{}'").format(x.name, value)
                    #t1 = '# INDEX({}-{}), FMT({}), FMT_SIZE({})\n'.format(_start_index, index, x.parser.fmt, struct.calcsize(x.parser.fmt))
                    # self.debug('{:<86}{}', t0, t1)
                else:
                    # data = buf[index:index+x.skip_bytes]
                    # if x.name:
                    #     self._unknown[name] = data
                    # self._unknown_raw += data + b' '
                    # self.debug('>> skipping {} bytes from index {}\n>> {}\n', x.skip_bytes, index, data)
                    index += x.skip_bytes
            self.data.append(r)
        return index

    def pack(self):
        buf = self._header.parser.put(len(self.data))
        for d in self.data:
            i = 0
            for x in self._content:
                if x.skip_bytes is None:
                    value = d[i]
                    if not x.process is None:
                        value = x.process(value)
                    if x.parser is None:
                        buf += value
                    else:
                        buf += x.parser.put(value)
                    i += 1
                else:
                    buf += bytes(x.skip_bytes)
        return buf

    def dict(self):
        return {}

class GenericUDPPacket(GenericPacket):
    _id_fmt = 'B'

# =============================================================================
# >> TCP PACKETS
# =============================================================================
class ReqConnection(GenericPacket):
    packet_id = ACP_REQ_CONNECTION
    _content = (
        BytesData('protocol_version', UINT16),
        BytesData('steamid', ASCII),
        BytesData('name', UTF32),
        BytesData(skip_bytes=1), # Seems to be a string of ascii/UTF not sure what its used for but it appers in [] after driver name on connect
        BytesData('country', ASCII),
        BytesData('car_model', ASCII),
        BytesData('password', ASCII),
    )

class ServerInfo(GenericPacket):
    packet_id = ACP_SERVER_INFO
    _content = (
        BytesData('server_name', UTF32),
        BytesData(skip_bytes=2),
        BytesData('hz', UINT8),
        BytesData('track', ASCII),
        BytesData('layout', ASCII),
        BytesData('car_model', ASCII),
        BytesData('car_skin', ASCII),
        BytesData(skip_bytes=4),
        BytesData('allowed_tyres_out', INT16),
        BytesData('tyre_blankets_allowed', UINT8),
        BytesData('tc_allowed', UINT8),
        BytesData('abs_allowed', UINT8),
        BytesData('stability_allowed', UINT8),
        BytesData('autoclutch_allowed', UINT8),
        BytesData('unknown0', UINT8), # Some 1/0 setting in from server i believe
        BytesData(skip_bytes=12), # Bytes connection with server Fuel/Tyre/DMG rate?
        BytesData('force_virtual_mirror', UINT8),
        BytesData(skip_bytes=17),
        BytesData('car_id', UINT8),
        BytesData(skip_bytes=4),
        BytesData('session_time_total', UINT16),
        BytesData('session_name', ASCII),
        BytesData(skip_bytes=10),
        BytesData('car_id1', UINT8), # Unreliable! sometimes gives wrong id
        BytesData('elapsed', UINT32), # Time the bot has been in server when you reach max number on this is has a small chance of disconnecting. Why? God knows
        BytesData(skip_bytes=5),
        BytesData('path_system', ASCII),
        BytesData('path_track', ASCII),
        BytesData('legal_tyres', ASCII),
        BytesData(skip_bytes=4),
        BytesData('server_time', UINT32),
    )

class ReqDriverList(GenericPacket):
    packet_id = ACP_REQ_DRIVER_LIST
    _content = BytesData('from_car_id', UINT8),

class AnsDriverList(VariablePacket):
    packet_id = ACP_ANS_DRIVER_LIST
    _header = BytesData('count', StructParser('>H'))
    _content = (
        BytesData('car_id', UINT8),
        BytesData('car_model', ASCII),
        BytesData('car_skin', ASCII),
        BytesData('name', UTF8),
        BytesData('country', StringParser('>H', 'ascii'), callback='process'),
    )

    def process(self, result, index):
        if result == 0:
            return index + 20
        return index + 21

class ReqTyreChange(GenericPacket):
    packet_id = ACP_REQ_TYRE_CHANGE
    _content = BytesData('tyre', ASCII),

class TyreChange(GenericPacket):
    packet_id = ACP_REQ_TYRE_CHANGE
    _content = (
        BytesData('car_id', UINT8),
        BytesData('tyre', ASCII),
    )

class Checksum(GenericPacket):
    packet_id = ACP_CHECKSUM
    _content = (
        BytesData('path_system', MD5),
        BytesData('path_track', MD5),
        BytesData('path_car', MD5),
    )

class RawChecksum(GenericPacket):
    packet_id = ACP_CHECKSUM
    _content = (
        BytesData('system', NOPARSER),
        BytesData('track', NOPARSER),
        BytesData('car', NOPARSER),
    )

class ReqDisconnect(GenericPacket):
    packet_id = ACP_REQ_DISCONNECT

class DriverNameList(VariablePacket):
    packet_id = ACP_DRIVER_NAME_LIST
    _content = (
        BytesData('car_id', INT8),
        BytesData('name', UTF32),
    )

class ClientDriverSync(GenericPacket):
    packet_id = ACP_DRIVER_SYNC
    _content = (
        BytesData('unknown0', INT8),
        BytesData('unknown1', INT8),
        BytesData('unknown2', INT8),
    )

class ServerDriverSync(GenericPacket):
    packet_id = ACP_DRIVER_SYNC
    _content = (
        BytesData('car_id', UINT8),
        BytesData('unknown0', INT16),
        BytesData('unknown1', INT8),
        #BytesData('unknown2', INT8),
    )

class ServerDriverSync2(GenericPacket):
    packet_id = ACP_DRIVER_SYNC2
    _content = (
        BytesData('car_id', UINT8),
        BytesData('value', UINT8),
    )

class Unknown112(VariablePacket):
    packet_id = ACP_UNKNOWN_112
    _content = (
        BytesData('car_id', UINT8),
        BytesData(skip_bytes=8),
    )

class DriverKick(GenericPacket):
    packet_id = ACP_DRIVER_KICK
    _content = (
        BytesData('car_id', UINT8),
        BytesData('code', UINT8),
    )

tcp_packet_map = {
    p.packet_id: p for p in [
        ServerInfo,
        AnsDriverList,
        DriverNameList,
        ServerDriverSync,
        ServerDriverSync2,
        TyreChange,
        Unknown112,
        DriverKick,
    ]
}

# =============================================================================
# >> UDP PACKETS
# =============================================================================
class UpdateCar(GenericUDPPacket):
    packet_id = ACP_UPDATE_CAR
    _content = (
        BytesData('frame', UINT8),
        BytesData('time', UINT32),
        BytesData('x_pos', FLOAT),
        BytesData('z_pos', FLOAT),
        BytesData('y_pos', FLOAT),
        BytesData('x_angle', FLOAT, process=math.radians),
        BytesData('z_angle', FLOAT, process=math.radians),
        BytesData('y_angle', FLOAT, process=math.radians),
        BytesData('x_velocity', FLOAT),
        BytesData('y_velocity', FLOAT),
        BytesData('z_velocity', FLOAT),
        BytesData('wheel_speed_fl', UINT8),
        BytesData('wheel_speed_fr', UINT8),
        BytesData('wheel_speed_rl', UINT8),
        BytesData('wheel_speed_rr', UINT8),
        BytesData('steer_wheel', UINT8),
        BytesData('steer_tyre', UINT8),
        BytesData('engine_rpm', INT16),
        BytesData('gear', INT8),
        BytesData('car_status', UINT8),
        BytesData(skip_bytes=5),
        BytesData('throttle', UINT8),
        # BytesData(skip_bytes=5),
    )

class ServerUpdateCar(UpdateCar):
    _content = (BytesData('car_id', UINT8),) + UpdateCar._content

class ServerPing(GenericUDPPacket):
    packet_id = ACP_SERVER_PING
    _content = (
        BytesData('token', UINT32),
        BytesData('ping', UINT16),
    )

class ClientPing(GenericUDPPacket):
    packet_id = ACP_CLIENT_PING
    _content = (
        BytesData('token', UINT32),
        BytesData('time', UINT32),
    )

class ClientAlive(GenericUDPPacket):
    packet_id = ACP_CLIENT_ALIVE
    _content = (
        BytesData('value', UINT8),
    )

udp_packet_map = {
    p.packet_id: p for p in [
        ServerPing,
        ServerUpdateCar,
    ]
}

# =============================================================================
# >> PROTOCOL
# =============================================================================
class CarInfo:

    def __init__(self):

        # Packet data
        self.frame = 0
        self.time = 0
        self.x_pos = 0
        self.y_pos = 0
        self.z_pos = 0
        self.x_angle = 0.0
        self.y_angle = 0.0
        self.z_angle = 0.0
        self.x_velocity = 0.0
        self.y_velocity = 0.0
        self.z_velocity = 0.0
        self.wheel_speed_fl = 100
        self.wheel_speed_fr = 100
        self.wheel_speed_rl = 100
        self.wheel_speed_rr = 100
        self.steer_wheel = 127
        self.steer_tyre = 127
        self.engine_rpm = 0
        self.gear = 0
        self.throttle = 0

        # Values unpacked from car_status part of checksum process
        self.brake_light = True    
        self.light = True
        self.horn = False
        self.wheel_smoke_fl = False
        self.wheel_smoke_fr = False
        self.wheel_smoke_rl = False
        self.wheel_smoke_rr = False

        # Other
        # self._origin_time = time.perf_counter()
        self.id = 0
        self.model = ''
        self.skin = ''

    def get_car_status(self):
        values = (0, self.horn, self.light, self.brake_light, self.wheel_smoke_rr, self.wheel_smoke_rl, self.wheel_smoke_fr, self.wheel_smoke_fl)
        return int(''.join('01'[x] for x in values), 2)

    def set_car_status(self, value):
        binary = '{0:{fill}8b}'.format(value, fill='0')
        # binary[0] = flash headlights?
        self.horn = binary[1] == '1'
        self.light = binary[2] == '1'
        self.brake_light = binary[3] == '1'
        self.wheel_smoke_rr = binary[4] == '1'
        self.wheel_smoke_rl = binary[5] == '1'
        self.wheel_smoke_fr = binary[6] == '1'
        self.wheel_smoke_fl = binary[7] == '1'

    # def get_time(self):
    #     return int((time.perf_counter() - self._origin_time) * 1000)

    # def set_time(self, value):
    #     self._time = value

    @property
    def real_gear(self):
        if self.gear < 2:
            return ['R', 'N'][self.gear]
        return self.gear - 1

    # Properties
    # time = property(get_time, set_time)
    car_status = property(get_car_status, set_car_status)

class ServerInfo:

    def __init__(self):
        self.server_name = ''
        self.hz = 0
        self.track = ''
        self.layout = ''
        self.car_id = 0
        self.car_model = ''
        self.car_skin = ''
        self.allowed_tyres_out = 0
        self.tyre_blankets_allowed = 0
        self.tc_allowed = 0
        self.abs_allowed = 0
        self.stability_allowed = 0
        self.autoclutch_allowed = 0
        self.unknown0 = 0
        self.force_virtual_mirror = 0
        self.session_time_total = 0
        self.session_name = 0
        self.car_id1 = 0
        self.elapsed = 0
        self.path_system = ''
        self.path_track = ''
        self.legal_tyres = ''
        self.server_time = 0

class BotManager(list):

    def __init__(self):
        super().__init__()
        self.index = 0
        self.bot_name_pool = list(BOT_NAMES)
        self.server_info = None
    
    def add(self, name=None, steamid=None, country_pool=COUNTRIES_EU, country=None):
        steamid = steamid or '{:017}'.format(len(self) + 1)
        name = name or random.choice(self.bot_name_pool)
        country = country or random.choice(country_pool or COUNTRIES)
        bot = Bot(name, steamid, country=country)
        if bot.connect():
            self.append(bot)
            if name in self.bot_name_pool:
                self.bot_name_pool.remove(name)
            self.index = len(self) - 1
            if self.server_info is None:
                self.server_info = bot.server
            return bot
        return None

    def remove(self, bot):
        super().remove(bot)
        bot.disconnect()
        if bot.name in BOT_NAMES:
            self.bot_name_pool.append(bot.name)
        if self.index > len(self) - 1:
            self.index = len(self) - 1

    def remove_active(self):
        bot = self.get_selected()
        if bot is None:
            print('No active bot')
            return
        self.remove(bot)

    def get_selected(self):
        try:
            return self[self.index]
        except IndexError:
            return None

    def disconnect(self):
        for b in list(self):
            self.remove(b)

    def fetch_server_info(self):
        if self.server_info:
            return self.server_info
        bot = self.add()
        if bot:
            self.server_info = value = bot.server
            self.remove(bot)
            return value
        return None

    def test(self):
        while True:
            bot_count = input('Bot count: ')
            if bot_count.isdigit():
                bot_count = int(bot_count)
                break
            elif bot_count == '*':
                return None
        bots = []
        if len(self):
            while True:
                answer = input('Do you want to include currently connected bots?\n(Y/N): ')
                if answer.lower() in ('y', 'yes'):
                    for b in self:
                        bots.append(b)
                        if len(bots) == bot_count:
                            break
                    break
                if answer.lower() in ('n', 'no'):
                    break
        bots_needed = bot_count - len(bots)
        for i in range(bots_needed):
            bot = self.add()
            if bot is None:
                break
            bots.append(bot)
        if not bots:
            return
        added_bots = len(bots)
        replay_path = load_file(
            base_dir=os.path.join(PATH_REPLAY, bots[0].server.track),
            file_type='replay')
        _print('Loading replay data for {} bots'.format(added_bots))
        for b in bots:
            b.replay.load(replay_path, start=False)
            _print('[{}] Replay loaded!'.format(b.name))
        while True:
            delay = input('Delay between bots: (0.1s - 10s): ')
            if delay == '*':
                return None
            try:
                delay = float(delay)
                if delay < 0.1:
                    delay = 0.1
                if delay > 10:
                    delay = 10
                break
            except ValueError:
                pass
        _print('Starting replays for {} bots. Time: {:.1f}s'.format(added_bots, added_bots*delay))
        for b in bots:
            b.replay.start_playback()
            if delay > 1:
                _print('[{}] Replay started!'.format(b.name))
            time.sleep(delay)
        print('Replays started for {} bots successfully!'.format(added_bots))

    def is_bot_port(self, port):
        for b in self:
            if b.udp.local_port == port:
                return True
        return False

    def save_setup(self):
        if len(self) < 2:
            print('Atleast 2 bots is required to save a position setup')
            return
        path = save_file(
            base_dir=os.path.join(PATH_POSITION, self[0].server.track),
            file_type='setup')
        attr = ('x_pos', 'z_pos', 'y_pos', 'x_angle', 'z_angle', 'y_angle')
        with open(path, 'w') as f:
            for b in self:
                f.write('&'.join(str(getattr(b.car, a)) for a in attr) + '\n')

    def load_setup(self):
        s = self.fetch_server_info()
        if s is None:
            return
        path = load_file(
            base_dir=os.path.join(PATH_POSITION, s.track),
            file_type='setup')
        if path is None:
            return
        with open(path, 'r') as f:
            result = f.readlines()
        count = len(result)
        bots = []
        for i in range(count):
            bot = self.add()
            if bot is None:
                print('Warning: Not all bots could connect when loading position setup. ({}/{})'.format(i, count))
                break
            bots.append(bot)
        i = 0
        for b in bots:
            b.load_position(result[i].strip())
            i += 1

class Bot:
    DISCONNECTED = 0
    CONNECTING = 1
    CONNECTED = 2
    KICKED = 3

    def __init__(self, name, steamid, car_model=CARNAME, country=COUNTRY):
        self.name = name
        self.steamid = steamid
        self.car_model = car_model
        self.country = country
        self.state = 0
        self.replay = ReplayPlayback(self)
        self.car = CarInfo()
        self.server = ServerInfo()
        self.tcp = TCPHandler(self)
        self.udp = UDPHandler(self)
        self.ping = 0
        self.move_step = 1.0

    def connect(self):
        if self.state != self.DISCONNECTED:
            print('Bot already connected')
            return
        try:
            print('Connecting "{}" to {}:{}...'.format(self.name, IP, PORT))
            self.tcp.socket.connect((IP, PORT))
            self.state = self.CONNECTING

            # Connect
            packet = ReqConnection(
                protocol_version=AC_PROTOCOL_VERSION,
                steamid=self.steamid,
                name=self.name,
                car_model=self.car_model,
                country=self.country,
                password=PASSWORD)
            self.tcp.send_packet(packet)

            # Server info
            p = self.tcp.recv_packet(ACP_SERVER_INFO)
            if p is None:
                raise ConnectionError('Unexpected response from connection request')

            for k,v in p.dict().items():
                if k in ('car_id', 'car_model', 'car_skin'):
                    setattr(self.car, k[4:], v)
                setattr(self.server, k, v)

            # Set spawn position
            attr = ('x_pos', 'y_pos', 'z_pos', 'x_angle', 'y_angle', 'z_angle')
            result = DRIFT_PITBOX_POSITION[self.car.id]
            for k,v in zip(attr, result):
                setattr(self.car, k, v)

            # Driver list
            self.req_driver_list()

            # No idea what this is exactly yet
            self.req_driver_sync()

            # AC client does this so..
            for i in range(2):
                self.req_tyre_change()

            # Initiate UDP
            if not self.udp.initiate(self.car.id):
                raise ConnectionError('Failed to initiate UDP communication with server')

            # Send checksums
            self.req_send_checksum()

            # Start threads
            self.tcp.start()
            self.udp.start(self.server.hz)
            self.state = self.CONNECTED
            print('Connected!')
            return True
        except ConnectionError as e:
            print(e.strerror)
            self.disconnect()
        except ProtocolError as e:
            print(e)
            self.disconnect()
        except socket.timeout:
            print('Connection attempt timed out')
        except socket.error as e:
            print(e)
        return False

    def disconnect(self):
        print('Disconnecting "{}"'.format(self.name))
        self.udp.stop()
        if self.state == self.CONNECTED:
            packet = ReqDisconnect()
            self.tcp.send_packet(packet)
        self.tcp.stop()
        self.state = self.DISCONNECTED
        print('Disconnected!')

    def load_position(self, data=None):
        try:
            filename = None
            if data is None:
                path = load_file(
                    base_dir=os.path.join(PATH_POSITION, self.server.track),
                    file_type='pos')
                if path is None:
                    return
                filename = os.path.basename(path)
                with open(path, 'r') as f:
                    result = f.readline().strip()
            else:
                result = data
            result = result.split('&')
            if len(result) != 6:
                raise Warning
            result = [float(x) for x in result]
        except:
            print('Could not load "{}". Invalid format'.format(filename))
        else:
            attr = ('x_pos', 'z_pos', 'y_pos', 'x_angle', 'z_angle', 'y_angle')
            for k,v in zip(attr, result):
                setattr(self.car, k, v)
            if filename:
                print('Position file "{}" Loaded!'.format(filename))
            else:
                print('Position Loaded!')

    def save_position(self):
        path = save_file(
            base_dir=os.path.join(PATH_POSITION, self.server.track),
            file_type='pos')
        if path is None:
            return
        attr = ('x_pos', 'z_pos', 'y_pos', 'x_angle', 'z_angle', 'y_angle')
        with open(path, 'w') as f:
            f.write('&'.join(str(getattr(self.car, a)) for a in attr))

    def load_replay(self):
        path = load_file(
            base_dir=os.path.join(PATH_REPLAY, self.server.track),
            file_type='replay')
        if path is None:
            return
        self.replay.load(path)

    def req_tyre_change(self, tyre='SM'):
        packet = ReqTyreChange(tyre=tyre)
        self.tcp.send_packet(packet)

    def req_driver_list(self, from_car_id=0):
        # Driver list, cap at 10 entries? so if
        # entry list >10 need to request driver list from index 10 aswell?
        # maybe not nessesary but AC client does it
        packet = ReqDriverList(from_car_id=from_car_id)
        self.tcp.send_packet(packet)

        # Can be issues with vareying byte length on this packet
        # and its not really critical we get this info so just ignore
        # if anything goes wrong..
        try:
            packet = self.tcp.recv_packet(ACP_ANS_DRIVER_LIST)
        except Exception as e: # Maybe be abit more specific (like ParserError)
            print(e)

    def req_send_checksum(self):
        # If checksum mismatch, what does server reply with then?
        # I dont think there is a direct response to this packet?
        if self.server is None:
            _print('Cant do checksum request before we have server info')
            return
        try:
            p0 = self.server.path_system
            p1 = self.server.path_track
            p2 = os.path.join('content', 'cars', self.car_model, 'data.acd')
            c = 0
            for p in (p0, p1, p2):
                c += 1
                abs_path = os.path.join(PATH_ASETTOCORSA, p)
                # _print(abs_path)
                with open(abs_path, 'rb') as f:
                    data = hashlib.md5(f.read()).digest()
                    if c == 3:
                        checksums['cars'][self.car_model] = data
                    else:
                        checksums[p] = data
        except Exception as e:
            _print('Error trying to read checksums from asettocorsa game dir')
        try:
            packet = RawChecksum(
                system=checksums[self.server.path_system],
                track=checksums[self.server.path_track],
                car=checksums['cars'][self.car_model])
        except KeyError:
            raise ProtocolError(5, 'Unable to load required checksum files') # This means one of your cars or tracks is missing a file needed.  Make sure that your checksum has run correctly
        self.tcp.send_packet(packet)

    def req_driver_sync(self):
        packet = ClientDriverSync(unknown0=-1, unknown1=-1, unknown2=0)
        self.tcp.send_packet(packet)
        packet = self.tcp.recv_packet(ACP_DRIVER_SYNC)

    def move_forward(self):
        self.car.x_pos, self.car.y_pos = move_vector(
            (self.car.x_pos, self.car.y_pos + self.move_step),
            math.radians(self.car.x_angle),
            (self.car.x_pos, self.car.y_pos))

    def move_backward(self):
        self.car.x_pos, self.car.y_pos = move_vector(
            (self.car.x_pos, self.car.y_pos - self.move_step),
            math.radians(self.car.x_angle),
            (self.car.x_pos, self.car.y_pos))

    def move_left(self):
        self.car.x_pos, self.car.y_pos = move_vector(
            (self.car.x_pos + self.move_step, self.car.y_pos),
            math.radians(self.car.x_angle),
            (self.car.x_pos, self.car.y_pos))

    def move_right(self):
        self.car.x_pos, self.car.y_pos = move_vector(
            (self.car.x_pos - self.move_step, self.car.y_pos),
            math.radians(self.car.x_angle),
            (self.car.x_pos, self.car.y_pos))

    def lift_up(self):
        self.car.z_pos += self.move_step

    def lift_down(self):
        self.car.z_pos -= self.move_step

    def rotate_yaw(self, w):
        self.car.x_angle += (self.move_step if self.move_step <= 2 else 2) * w

    def rotate_pitch(self, w):
        self.car.z_angle += (self.move_step if self.move_step <= 2 else 2) * w

    def rotate_roll(self, w):
        self.car.y_angle += (self.move_step if self.move_step <= 2 else 2) * w

class ThreadHelper:
    # all_threads = []
    exc_queue = queue.Queue()

    def __init__(self, thread_targets=[]):
        self.active = None
        self.threads = [threading.Thread(target=self.thread_handler, args=(x,)) for x in thread_targets]
        # self.all_threads.append(self.threads)

    def create_thread(self, *args, target=None, daemon=False, **kw):
        thread_args = (target,)
        if 'args' in kw:
            thread_args = thread_args + kw['args']
        t = threading.Thread(*args, target=self.thread_handler, args=thread_args, **kw)
        t.daemon = daemon
        self.threads.append(t)
        # self.all_threads.append([t])

    def start(self):
        if self.active is None:
            self.active = True
            for t in self.threads:
                t.start()
        else:
            raise Warning('Threads can only be started once!')

    def stop(self):
        if self.active:
            self.active = False
            #try:
            for t in self.threads:
                t.join()
            #except RuntimeError as e:
            #    print('ThreadHelper:stop >> RuntimeError: {}'.format(e))

    def thread_handler(self, method):
        try:
            while self.active:
                value = method()
                if value is None:
                    continue
                time.sleep(value)
        except Exception as exc:
            self.exc_queue.put((threading.current_thread(), exc))

    @classmethod
    def raise_thread_exceptions(cls):
        try:
            thread, exc = cls.exc_queue.get(block=False)
            _print('Exception in thread "{}"'.format(thread.name))
            raise exc
        except queue.Empty:
            pass

class UDPHandler(ThreadHelper):
    
    def __init__(self, bot):
        super().__init__(thread_targets=[self.receive])
        self.address = (IP, PORT)
        self.bot = bot
        self.frame = 0
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(('', 0))
        self.socket.settimeout(0.5)
        self.local_port = self.socket.getsockname()[1]
        self.ref_time = time.perf_counter()
        self.last_update = 0
        self.ping_count = -5
        self.update_rate = 1 / (18 + 1) # 18 = default server hz
        self.req_map = {
            ACP_SERVER_PING: self.req_server_ping,
            ACP_UPDATE_CAR: self.req_update_car,
        }

    def start(self, server_hz):
        self.update_rate = 1 / (server_hz + 1)
        # print('UDP Update interval set to {}hz'.format(server_hz))
        super().start()

    def stop(self):
        super().stop()
        self.socket.close()

    def initiate(self, car_id):
        data = struct.pack('B', ACP_INIT_UDP) + bytes([car_id])
        retries = 3
        while retries:
            retries -= 1
            self.socket.sendto(data, self.address)
            data, addr = self.socket.recvfrom(1024)
            if addr != self.address:
                print('(UDP INIT) Invalid UDP source address')
                continue
            if not data:
                print('(UDP INIT) No data')
                continue
            p_id, = struct.unpack_from('B', data, 0)
            if p_id != ACP_INIT_UDP:
                print('(UDP INIT) Unexpected packed ID {} received'.format(p_id))
                continue
            break
        else:
            return False
        return True

    # def send(self):
    #     packet = UpdateCar(
    #         _obj=self.bot.car,
    #         frame=self.frame,
    #         time=int((time.perf_counter() - self.ref_time) * 1000))
    #     self.socket.sendto(packet.to_buffer(), self.address)
    #     self.frame += 1
    #     if self.frame > 255:
    #         self.frame = 0
    #     return self.update_rate

    def update_car(self, now):
        if self.bot.state != 2:
            return
        if now - self.last_update >= self.update_rate:
            packet = UpdateCar(
                _obj=self.bot.car,
                frame=self.frame,
                time=int((now - self.ref_time) * 1000))
            self.socket.sendto(packet.to_buffer(), self.address)
            self.frame += 1
            if self.frame > 255:
                self.frame = 0
            self.last_update = now

    def receive(self):
        try:
            data, addr = self.socket.recvfrom(1024)
            if addr != self.address:
                print('Invalid UDP source address')
                return
            if not data:
                return
            index = 0
            p_id, = struct.unpack_from('B', data, index)
            index += 1
            if p_id not in udp_packet_map:
                print('Unknown UDP packet received ID: {}'.format(p_id))
                return
            if p_id not in self.req_map:
                print('No request method registred for packet ID: {}'.format(p_id))
                return
            p = udp_packet_map[p_id]()
            p.from_buffer(data, index)
            self.req_map[p_id](p)

        except socket.timeout:
            return

    def req_server_ping(self, p):
        self.bot.ping = p.ping
        packet = ClientPing(
            token=p.token,
            time=int((time.perf_counter() - self.ref_time) * 1000))
        self.socket.sendto(packet.to_buffer(), self.address)
        self.ping_count += 1
        if self.ping_count == 2:
            packet = ClientAlive(value=1)
            self.socket.sendto(packet.to_buffer(), self.address)
            self.ping_count = 0

    def req_update_car(self, p):
        return

class TCPHandler(ThreadHelper):
    
    def __init__(self, bot):
        super().__init__(thread_targets=[self.send, self.receive])
        self.address = (IP, PORT)
        self.bot = bot
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.settimeout(5)
        self.lock = threading.RLock()
        self.req_map = {
            ACP_DRIVER_KICK: self.req_driver_kick,
        }

    def stop(self):
        super().stop()
        self.socket.close()

    def send(self):
        return 0.1

    def receive(self):
        try:
            packet = self.recv_packet(timeout=0.1)
            if packet is None:
                return
            # print('Received TCP packet {} ({})'.format(packet.packet_id, packet.__class__))
            try:
                self.req_map[packet.packet_id](packet)
            except KeyError:
                pass
        except socket.timeout:
            return
        except Warning as e:
            print(e)

    def send_raw(self, data):
        self.socket.sendall(data)

    def send_packet(self, packet):
        buf = packet.to_buffer()
        buf_size = len(buf)
        buf = struct.pack(P_SIZE_FMT, buf_size) + buf
        #print('\n' + '*' * 112)
        #print('Sending packet id {} ({})'.format(packet.packet_id, PACKET_ID_TRANSLATION[packet.packet_id]))
        # for x in packet._content:
        #     if x.name:
        #         print('{}={}'.format(x.name, getattr(packet, x.name)))
        try:
            self.socket.sendall(buf)
        except ConnectionResetError:
            pass

    def recv_packet(self, expected_id=None, timeout=10, max_size=12288):
        with self.lock:
            try:
                packet = self.recv(timeout, max_size)
                if expected_id == packet.packet_id or expected_id is None:
                    return packet
                raise ProtocolError(2, 'Expected to receive packet {} but got {}', expected_id, packet.packet_id)
            except ProtocolError as e:
                if e.errno in (1, 3, 4): # Ignore these for now
                    return
                raise

    def recv(self, timeout, max_size):
        self.socket.settimeout(timeout)
        max_buf_size = 1024
        buf = b''
        buf_size = 0
        total_size = 0
        bytes_recv = 0
        size_received = False
        index = 0

        while True:
            buf_size = (total_size - bytes_recv) if size_received else max_buf_size
            if buf_size > max_buf_size:
                buf_size = max_buf_size
            chunk = self.socket.recv(buf_size)
            if chunk == b'':
                raise Warning('EOF/Connection closed')
            buf += chunk
            bytes_recv += len(chunk)
            if not size_received:
                if bytes_recv >= P_SIZE_FMT_LEN:
                    size, = struct.unpack_from(P_SIZE_FMT, buf, index)
                    index += P_SIZE_FMT_LEN
                    size = size + P_SIZE_FMT_LEN
                    if size > max_size:
                        raise Warning('Received packet size exceed max allowed size')
                    elif size < bytes_recv:
                        # raise Warning('Received packet size({}) is less than current received bytes({}) Data: {}'.format(size, bytes_recv, buf))
                        # raise Warning('Current received bytes({}) exceedes claimed total size({})'.format(bytes_recv, size))
                        raise ProtocolError(1, 'Current received bytes({}) exceedes claimed total size({})', bytes_recv, size)
                    total_size = size
                    size_received = True
            if bytes_recv == total_size:
                packet_id, = struct.unpack_from(P_ID_FMT, buf, index)
                index += P_ID_FMT_LEN
                if packet_id in tcp_packet_map:
                    packet = tcp_packet_map[packet_id]()
                    packet.from_buffer(buf, index)
                    return packet
                if packet_id in (ACP_INVALID_PASSWORD, ACP_SERVER_FULL, ACP_INVALID_PROTOCOL):
                    raise ConnectionError('Connection denied: {}'.format(PACKET_ID_TRANSLATION[packet_id]))
                if packet_id in PACKET_ID_TRANSLATION: # Just so we dont get "unknown packet" while i dont have any packet instnaces ready yet
                    raise ProtocolError(4, 'No TCP packet is registred for ID {} ({})', packet_id, PACKET_ID_TRANSLATION[packet_id])
                raise ProtocolError(3, 'Unknown TCP packet received {}', packet_id)
            elif bytes_recv < total_size:
                continue
            if bytes_recv > max_size:
                raise Warning('Bytes received exceeded maximum allowed size')
            raise Warning('More bytes received than expected')

    def req_driver_kick(self, p):
        if p.car_id == self.bot.car.id:
            print('[{}] got kicked with code {}'.format(self.bot.name, p.code))
            # bot_manager.remove(self.bot)
            # self.bot.state = self.bot.KICKED
            main_thread(bot_manager.remove, self.bot)

    # def recv_packet(self, expected_id=None, timeout=10, max_size=12288):
    #     print('\n' + '*' * 112)
    #     print('Waiting for packet id {} ({})'.format(expected_id, PACKET_ID_TRANSLATION[expected_id]))
    #     packet = self.recv(timeout, max_size)
    #     if expected_id == packet.packet_id or expected_id is None:
    #         print('OK. Received packet id {}'.format(packet.packet_id))
    #         print('Result:')
    #         if isinstance(packet, VariablePacket):
    #             data_count = len(packet.data)
    #             print('Data Count: {}'.format(data_count))
    #             for i in range(data_count):
    #                 print('[{}]'.format(i) + '-' * 64)
    #                 c = 0
    #                 for x in packet._content:
    #                     print('{}={}'.format(x.name, packet.data[i][c]))
    #                     c += 1
    #         else:
    #             for x in packet._content:
    #                 if x.name:
    #                     print('{}={}'.format(x.name, getattr(packet, x.name)))
    #         return packet
    #     raise Warning('Expected to receive packet {} but got {}'.format(expected_id, packet.packet_id))

class Replay:

    def __init__(self, hz, track, layout, replay_data):
        self.hz = hz
        self.track = track
        self.layout = layout
        self.index = 0
        self.frames = []
        self.update_rate = 1 / (hz + 1)
        for frame in replay_data:
            car = CarInfo()
            car.__dict__.update(frame)
            for a in ('x_angle', 'y_angle', 'z_angle'):
                setattr(car, a, math.degrees(frame[a]))
            self.frames.append(car)
        self.end_index = len(self.frames) - 1

    # def get_data(self):
    #     if self.index > self.end_index:
    #         self.index = 0
    #     car = self.frames[self.index]
    #     self.index += 1
    #     return car

    def get_data(self):
        if self.index > self.end_index:
            self.index = 0
        car = self.frames[self.index]
        self.index += 1
        return car

class ReplayPlayback(ThreadHelper):
    INACTIVE = 0
    PAUSED = 1
    PLAYBACK = 2
    WAITING = 3
    STATE_TO_STR = [
        'INACTIVE',
        'PAUSED',
        'PLAYBACK',
        'WAITING',
    ]

    def __init__(self, bot):
        # super().__init__(thread_targets=[self.run])
        self.bot = bot
        self.state = self.INACTIVE
        self.replay = None
        self.timelimit = None
        self.filename = ''
        # self.start()
        self.diff = 0
        self.last_update = 0

    # def run(self):
    #     if self.state == self.PLAYBACK:
    #         self.bot.car = self.replay.get_data()
    #         return 1 / (self.replay.hz + 1)
    #     elif self.state == self.WAITING:
    #         return 0.001
    #     return 0.1

    # def run(self):
    #     last_update = 0
    #     diff = 0
    #     while self.active:
    #         if self.state == self.PLAYBACK:
    #             now = time.perf_counter()
    #             if now - last_update > diff:
    #                 self.bot.car, diff = self.replay.get_data()
    #                 last_update = now
    #             time.sleep(0.001)
    #         elif self.state == self.WAITING:
    #             time.sleep(0.001)
    #         else:
    #             time.sleep(0.1)

    def update(self, now):
        if self.state == self.PLAYBACK:
            if now - self.last_update > self.replay.update_rate:
                self.bot.car = self.replay.get_data()
                self.last_update = now

    def load(self, path, start=True):
        self.filename = os.path.basename(path)
        data = replay_manager.load_replay(path)
        self.replay = Replay(**data)
        if self.replay.track != self.bot.server.track:
            print('Playback failed! This replay is recorded on a diffrent track ({})'.format(self.bot.server.track))
            return False
        elif self.replay.layout != self.bot.server.layout:
            print('Playback failed! This replay is recorded on a diffrent layout ({})'.format(self.bot.server.layout))
            return False
        if start:
            self.start_playback()
        else:
            self.state = self.WAITING

    def start_playback(self):
        self.state = self.PLAYBACK

    def get_state(self):
        if self.state == self.PLAYBACK:
            return self.STATE_TO_STR[self.state] + ' ({})'.format(self.filename)
        return self.STATE_TO_STR[self.state]

class ReplayManager(ThreadHelper):
    INACTIVE = 0
    RECORDING = 1
    WAITING = 2
    STATE_TO_STR = [
        'INACTIVE',
        'RECORDING',
        'WAITING',
    ]

    def __init__(self, max_replay_size=25):
        super().__init__(thread_targets=[self.run])
        self.state = self.INACTIVE
        self.srv_ip = IP
        self.srv_port = PORT
        self.max_replay_size = max_replay_size * 1048576
        self.socket = None
        self.local_ip = socket.gethostbyname(socket.gethostname())
        self.replay_size = 0
        self.min_data_count = 0
        self.buffer = []
        self.filename = ''
        self.path_file = ''
        self.timelimit = None
        self.server = None
        self.last_wait_update = 0
        self.delay = 0
        self.file_header = (
            BytesData('hz', UINT8),
            BytesData('track', ASCII),
            BytesData('layout', ASCII),
            # BytesData('car_model', ASCII),
        )
        self.cache = {}
        try:
            self.socket = socket.socket(socket.AF_INET , socket.SOCK_RAW , socket.IPPROTO_IP)
            self.socket.bind((self.local_ip, 0))
            self.socket.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            self.socket.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)
            self.socket.settimeout(0.1)
            self.start()
            self.can_record = True
        except OSError:
            self.can_record = False
            print('Warning: Administrator rights is needed for record function to work!')

    def load_replay(self, path):
        filename = os.path.basename(path)
        try:
            return self.cache[filename]
        except KeyError:
            with open(path, 'rb') as f:
                header = binascii.unhexlify(f.readline().strip())
                index = 0
                data = {}
                for x in self.file_header:
                    value, index = x.parser.get(header, index)
                    data[x.name] = value
                data['replay_data'] = []
                for line in f.readlines():
                    index = 0
                    buf = binascii.unhexlify(line.strip())
                    p = UpdateCar()
                    p.from_buffer(buf, index)
                    data['replay_data'].append(p.dict())
                self.cache[filename] = data
                return data

    def toggle_record(self):
        if self.state == self.RECORDING:
            self.stop_record()
        elif self.state == self.INACTIVE:
            self.start_record()
        elif self.state == self.WAITING:
            self.state = self.INACTIVE
            print('Recording cancelled')

    def start_record(self):
        if not self.can_record:
            print('Program needs administrator rights for record function')
            return
        if self.state == self.INACTIVE:
            self.server = bot_manager.fetch_server_info()
            if self.server is None:
                print('Record function unavailable')
                return
            path = save_file(
                base_dir=os.path.join(PATH_REPLAY, self.server.track),
                file_type='replay')
            if path is None:
                return
            self.delay = 3
            self.replay_size = 0
            self.path_file = path
            print('Waiting for car data to begin. Recording will start on the 4th beep')
            self.min_data_count = 50
            self.state = self.WAITING

    def stop_record(self):
        if self.state == self.RECORDING:
            self.state = self.INACTIVE
            print('Recodring stopped. Size: {:.2f}MB. Saving to:'.format(self.replay_size / 1048576))
            print(self.path_file)
            with open(self.path_file, 'wb') as f:
                header = b''
                for x in self.file_header:
                    header += x.parser.put(getattr(self.server, x.name))
                f.write(binascii.hexlify(header) + b'\r\n')
                for l in self.buffer:
                    f.write(binascii.hexlify(l) + b'\r\n')
            self.buffer.clear()
            print('Save OK!')
        else:
            print('No recording is active')

    def run(self):
        data = self.recv_car_data()
        if data is None:
            return
        if self.state == self.RECORDING:
            self.replay_size += 118 # len(data) so once we hexlify the bytes data increases abit. Results in 116 bytes insted of 64
            self.buffer.append(data)
            if self.replay_size > self.max_replay_size:
                print('Warning: Max replay size exceeded ({.1f}MB / {.1f}MB) Stopping..'.format(
                    self.replay_size / 1048576,
                    self.max_replay_size / 1048576))
                self.stop_record()

        elif self.state == self.WAITING:
            if self.min_data_count:
                self.min_data_count -= 1
            else:
                now = time.perf_counter()
                if now - self.last_wait_update >= 1:
                    if self.delay:
                        if self.delay <= 3:
                            winsound.Beep(1000, 250)
                        self.delay -= 1
                    else:
                        self.state = self.RECORDING
                        winsound.Beep(1500, 1000)
                        print('Recording is now active!')  
                    self.last_wait_update = now

    def recv_car_data(self):

        # Capture packet
        try:
            data = self.socket.recvfrom(65565)
        except socket.timeout:
            return None
        if not data:
            return None
        packet = data[0]

        # Ethernet header length
        eth_length = 0

        # Parse IP header
        # Remove first 20 bytes for the ip header
        ip_header = packet[eth_length:20+eth_length]
         
        # Unpack ip header
        iph = struct.unpack('!BBHHHBBH4s4s' , ip_header)

        version_ihl = iph[0]
        version = version_ihl >> 4
        ihl = version_ihl & 0xF

        iph_length = ihl * 4

        ttl = iph[5]
        protocol = iph[6]
        source_ip = socket.inet_ntoa(iph[8])
        destination_ip = socket.inet_ntoa(iph[9])

        # Dismiss packets not coming from local computer
        if source_ip != self.local_ip:
            return None

        # Dismiss packets not going to server
        if destination_ip != self.srv_ip:
            return None

        # =====================================================================
        # >> UDP Packets
        # =====================================================================
        if protocol == 17:
            u = iph_length + eth_length
            udph_length = 8
            udp_header = packet[u:u+8]

            # Unpack UDP header
            udp_header = struct.unpack('!HHHH' , udp_header)
             
            source_port = udp_header[0]
            destination_port = udp_header[1]
            length = udp_header[2]
            checksum = udp_header[3]

            if destination_port != self.srv_port:
                return None

            # Is this a bot packet?
            if bot_manager.is_bot_port(source_port):
                return None

            h_size = eth_length + iph_length + udph_length
            data_size = len(packet) - h_size
            data = packet[h_size:]

            if len(data) < 1:
                return None

            index = 0
            fmt = 'B'
            packet_id, = struct.unpack_from(fmt, data, index)
            if packet_id == ACP_UPDATE_CAR:
                return data[1:]
        return None

    def is_active(self):
        return self.state != self.INACTIVE

    def get_display_text(self):
        text = (
            '{0}Recording.{0}\n'.format('-' * 55) +
            'State: {0}\n'
            'Replay Size: {1:.2f}/{2:.2f}MB\n\n'
            'Press 5 to stop\n'  + '-' * 120).format(
                self.STATE_TO_STR[self.state], self.replay_size / 1048576,
                self.max_replay_size / 1048576)
        return text

class CMD:

    def __init__(self, callback=None, pass_bot=False, pause_console=False, bot_method=None, args=()):
        self.callback = callback
        self.pass_bot = pass_bot
        self.pause_console = pause_console
        self.bot_method = bot_method
        if not isinstance(args, (tuple, list)):
            args = args,
        self.args = args

    def __call__(self, bot):
        if self.pause_console:
           console.pause()
        if self.bot_method:
            if bot:
                getattr(bot, self.bot_method)(*self.args)
            else:
                print('No bot selected')
        elif self.callback:
            # args = (bot,) + self.args
            self.callback(bot) if self.pass_bot else self.callback()
        console.resume()

class Console(ThreadHelper):

    def __init__(self):
        super().__init__()
        self.step_selection = list(range(1, 10)) + list(range(10, 100, 10)) + list(range(100, 1000, 50))
        self.step_index = 9
        self.update_rate = 0.2
        self._pause = False
        self._drawing = None
        self.bot = None
        self.create_thread(target=self.update, daemon=True)
        self.start()
        self.key_map = {
            KEY_ADD_BOT: CMD(bot_manager.add),
            KEY_REMOVE_BOT: CMD(bot_manager.remove_active),
            KEY_LOAD_POSITION: CMD(bot_method='load_position', pause_console=True),
            KEY_SAVE_POSITION: CMD(bot_method='save_position', pause_console=True),
            KEY_TOGGLE_RECORD: CMD(replay_manager.toggle_record, pause_console=True),
            KEY_LOAD_REPLAY: CMD(bot_method='load_replay', pause_console=True),
            KEY_LOAD_POSITION_SETUP: CMD(bot_manager.load_setup, pause_console=True),
            KEY_SAVE_POSITION_SETUP: CMD(bot_manager.save_setup, pause_console=True),
            b'9': CMD(bot_manager.test, pause_console=True),
            b'w': CMD(bot_method='move_forward'),
            b's': CMD(bot_method='move_backward'),
            b'a': CMD(bot_method='move_left'),
            b'd': CMD(bot_method='move_right'),
            b'r': CMD(bot_method='lift_up'),
            b'f': CMD(bot_method='lift_down'),
            b'q': CMD(bot_method='rotate_yaw', args=-20),
            b'e': CMD(bot_method='rotate_yaw', args=20),
            b't': CMD(bot_method='rotate_pitch', args=-20),
            b'g': CMD(bot_method='rotate_pitch', args=20),
            b'z': CMD(bot_method='rotate_roll', args=-20),
            b'c': CMD(bot_method='rotate_roll', args=20),
            # b'': CMD(bot_method=''),
        }

    def key_listener(self):
        if not msvcrt.kbhit():
            return
        key = msvcrt.getch().lower()
        bot = bot_manager.get_selected()
        if key in self.key_map:
            self.key_map[key](bot)
        elif key == KEY_NEXT_BOT:
            if bot_manager.index + 1 == len(bot_manager):
                bot_manager.index = 0
            else:
                bot_manager.index += 1
        elif key == KEY_PREVIOUS_BOT:
            if bot_manager.index == 0:
                bot_manager.index = len(bot_manager) - 1
            else:
                bot_manager.index -= 1
        elif key == b'o':
            self.step_index += 1
            if self.step_index > len(self.step_selection) - 1:
                self.step_index = 0
            bot.move_step = self.step_selection[self.step_index] / 10
            # if bot.move_step < 1:
            #     bot.move_step += 0.1
            # else:
            #     bot.move_step += 1
        elif key == b'p':
            self.step_index -= 1
            if self.step_index < 0:
                self.step_index = len(self.step_selection) - 1
            bot.move_step = self.step_selection[self.step_index] / 10
            # if bot.move_step - 0.1 < 0.1:
            #     bot.move_step = 0.1
            # elif bot.move_step - 1 < 1:
            #     bot.move_step -= 0.1
            # else:
            #     bot.move_step -= 1

    def update(self):
        if self._pause:
            return self.update_rate
        self.drawing = True
        bot = bot_manager.get_selected()
        text = '\x1b[0;31;47m'
        free_rows = console_rows - 1
        if bot:
            text += (
                '{}/{}\n'.format(bot_manager.index+1, len(bot_manager)) +
                'Bot name: {0.name} ({0.ping}ms) ({2})\n'
                'Replay: {3}\n'
                'Move step: {0.move_step:.1f}\n\n'
                'X position:{1.x_pos:^10.2f}X velocity{1.x_velocity:^10.2f}X angle:{1.x_angle:^10.2f}'
                'Engine RPM:{1.engine_rpm:^5}Light:{1.light:^5}\n'
                'Y position:{1.y_pos:^10.2f}Y velocity{1.y_velocity:^10.2f}Y angle:{1.y_angle:^10.2f}'
                'Gear:      {1.real_gear:^5}Horn: {1.horn:^5}\n'
                'Z position:{1.z_pos:^10.2f}Z velocity{1.z_velocity:^10.2f}Z angle:{1.z_angle:^10.2f}'
                'Brake:     {1.brake_light:^5}\n\n').format(
                    bot, bot.car, BOT_STATE[bot.state], bot.replay.get_state())
        if replay_manager.is_active():
            text += replay_manager.get_display_text()
        else:
            text += (
                '{0}Key control List{0}\n'.format('-' * 52) +
                '[W/S] Move Forwad/Backward      [O/P] Increase/Decrease move step\n'
                '[A/D] Move Left/Right           [R/F] Lift Up/Down\n'
                '[Q/E] Rotate Yaw                [T/G] Rotate Pitch\n'
                '[Z/C] Rotate Roll               [K] \n'
                '[1] Add Bot                     [6] Load Replay\n'
                '[2] Remove Bot                  [7] Load Position Setup\n'
                '[3] Save Position               [8] Save Position Setup\n'
                '[4] Load Position               [9] Replay Tandem\n'
                '[5] Toggle Recording            [+/-] Switch selected bot\n'
                '[Ctrl+C] Disconnect & Close\n' + '-' * 120)
        text_split = text.split('\n')
        text_rows = len(text_split)
        os.system('cls')
        for t in text_split:
            _print(t)
            free_rows -= 1
            if free_rows == 0:
                break
        if free_rows:
            for m in messages[-free_rows:]:
                _print(m)
        self.drawing = False
        return self.update_rate

    def pause(self, timeout=0):
        self._pause = True
        while self.drawing:
            time.sleep(0.05)

    def resume(self):
        self._pause = False

# =============================================================================
# >> FUNCTIONS
# =============================================================================
def print(text):
    text = '[{}] {}'.format(time.strftime('%H:%S'), text)
    if len(messages) > 100:
        messages.pop(0)
    messages.append(text)

def load_file(base_dir, file_type=''):
    try:
        files = os.listdir(base_dir)
    except FileNotFoundError:
        print('No saves for current track')
        return None
    if file_type:
        for f in list(files):
            if not f.endswith('.' + file_type):
                files.remove(f)
    files_total = len(files)
    page = 0
    page_size = 10
    page_total = files_total // page_size
    while True:
        os.system('cls')
        if page_total > 0:
            text = ' Page: {}/{} '.format(page+1, page_total+1)
            _print('{:-^120}'.format(text))
        else:
            _print('-'*120)
        for i in range(page_size):
            index = i + page * page_size
            if index > files_total - 1:
                break
            _print('[{}] {}'.format(i, files[index]))
        if page_total > 0:
            if page < page_total:
                _print('[+] Next Page')
            if page > 0:
                _print('[-] Previous Page')
        _print('[*] Back')
        _print('-' * 120)
        choice = input('Choice: ').lower()
        if choice == '-':
            if page > 0:
                page -= 1
        elif choice == '+':
            if page < page_total:
                page += 1
        elif choice == '*':
            return None
        elif choice.isdigit():
            choice = int(choice)
            index = choice + page * page_size
            if index < files_total:
                return os.path.join(base_dir, files[index])

def save_file(base_dir, file_type):
    os.makedirs(base_dir, exist_ok=True)
    while True:
        _print('[*] Back')
        filename = input('File name: ')
        if filename.lower() == '*':
            return None
        path = os.path.join(base_dir, filename + '.' + file_type)
        if not os.path.isfile(path):
            break
        answer = input('File already exist! Do you want to overwrite?\n(Y/N): ')
        if answer.lower() in ('y', 'yes'):
            break
    return path

def get_console_rows():
    h = ctypes.windll.kernel32.GetStdHandle(-12)
    csbi = ctypes.create_string_buffer(22)
    res = ctypes.windll.kernel32.GetConsoleScreenBufferInfo(h, csbi)
    if res:
        (bufx, bufy, curx, cury, wattr,
         left, top, right, bottom, maxx, maxy) = struct.unpack('hhhhHhhhhhh', csbi.raw)
        sizex = right - left + 1
        sizey = bottom - top + 1
    else:
        return console_rows
    return sizey

def move_vector(v, angle, anchor):
    x, y = v

    x = x - anchor[0]
    y = y - anchor[1]

    cos_theta = math.cos(angle)
    sin_theta = math.sin(angle)

    nx = x * cos_theta - y * sin_theta
    ny = x * sin_theta + y * cos_theta

    nx = nx + anchor[0]
    ny = ny + anchor[1]
    return [nx, ny]

class _BotUpdaterTest(ThreadHelper):

    def __init__(self):
        super().__init__(thread_targets=[self.replay_updater, self.car_updater])
        self.start()

    def replay_updater(self):
        now = time.perf_counter()
        for b in bot_manager:
            b.replay.update(now)
        return 0.001

    def car_updater(self):
        now = time.perf_counter()
        for b in bot_manager:
            b.udp.update_car(now)
        return 0.001

q = queue.Queue()
def main_thread(fn, *args, **kw):
    q.put((fn, args, kw))

def check_queue():
    try:
        fn, args, kw = q.get_nowait()
        fn(*args, **kw)
    except queue.Empty:
        pass

# =============================================================================
# >> PROGRAM
# =============================================================================
if __name__ == '__main__':
    error = ''
    console_rows = 30
    for p in (PATH_POSITION, PATH_REPLAY):
        if not os.path.isdir(p):
            os.mkdir(p)
    try:
        try:
            p = os.path.join(PATH_ROOT, 'checksum')
            with open(p, 'rb') as f:
                checksums = pickle.loads(f.read())
        except Exception as e:
            checksums = {'cars': {}}
        bot_manager = BotManager()
        replay_manager = ReplayManager()
        console = Console()
    except:
        print(traceback.format_exc())
        sys.exit(0)

    x = _BotUpdaterTest()

    try:
        while console.active:
            console.key_listener()
            check_queue()
            ThreadHelper.raise_thread_exceptions()
            console_rows = get_console_rows()
            time.sleep(0.01)
    except KeyboardInterrupt:
        print('Exiting..')
    except:
        error = traceback.format_exc()
    console.stop()
    _print('Disconnecting bots..')
    bot_manager.disconnect()
    if error:
        _print(error)
    input('Shutdown OK')
