import os
import sys
import hashlib
import pickle

for f in ('system', 'content'):
    if not os.path.isdir(f):
        input('Could not find system/content folders')
        sys.exit(0)
result = {'cars': {}}
cars = os.listdir(os.path.join('content', 'cars'))
tracks = os.listdir(os.path.join('content', 'tracks'))
system = os.path.join('system', 'data', 'surfaces.ini')
with open(system, 'rb') as f:
    result[system.replace('\\', '/')] = hashlib.md5(f.read()).digest()
for car in cars:
    path_data = os.path.join('content', 'cars', car, 'data')
    path_data_acd = path_data + '.acd'
    if os.path.isfile(path_data_acd):
        with open(path_data_acd, 'rb') as f:
            result['cars'][car] = hashlib.md5(f.read()).digest()
        print(path_data_acd)
    elif os.path.isdir(path_data):
        for file in os.listdir(path_data):
            path_file = os.path.join(path_data, file)
            with open(path_file, 'rb') as f:
                result['cars'][car] = hashlib.md5(f.read()).digest()
            print(path_file)
for track in tracks:
    path_track = os.path.join('content', 'tracks', track)
    path_data = os.path.join(path_track, 'data')
    if os.path.isdir(path_data):
        path = os.path.join(path_data, 'surfaces.ini')
        with open(path, 'rb') as f:
            result[path.replace('\\', '/')] = hashlib.md5(f.read()).digest()
        print(path)
    else:
        for layout in os.listdir(path_track):
            path = os.path.join(path_track, layout, 'data', 'surfaces.ini')
            if os.path.isfile(path):
                with open(path, 'rb') as f:
                    result[path.replace('\\', '/')] = hashlib.md5(f.read()).digest()
                print(path)
with open('checksum', 'wb') as f:
    f.write(pickle.dumps(result))
print('\nFinnished processing {} cars and {} tracks. Output file: checksum'.format(len(cars), len(tracks)))
input()